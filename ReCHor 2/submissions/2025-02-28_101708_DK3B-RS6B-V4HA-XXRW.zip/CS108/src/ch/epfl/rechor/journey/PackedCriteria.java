package ch.epfl.rechor.journey;

import ch.epfl.rechor.Preconditions;

import static java.lang.Integer.toUnsignedLong;

public class PackedCriteria {
    private PackedCriteria() {}

    public static long pack(int arrMins, int changes, int payload) {
        Preconditions.checkArgument((changes >> 7) == 0);
        Preconditions.checkArgument(arrMins >= -240);
        Preconditions.checkArgument(arrMins < 2880);
        return (toUnsignedLong(arrMins + 240) << 39) | (toUnsignedLong(changes) << 32) | (toUnsignedLong(payload));
    }

    public static boolean hasDepMins(long criteria) {
        return (criteria & 0b0111111111111000000000000000000000000000000000000000000000000000L) != 0;
    }

    public static int depMins(long criteria) {
        Preconditions.checkArgument(hasDepMins(criteria));
        return (int) (~(criteria >> 51) & 0b111111111111) - 240;
    }

    public static int arrMins(long criteria) {
        return (int) ((criteria >> 39) & 0b111111111111) - 240;
    }

    public static int changes(long criteria) {
        return (int) ((criteria >> 32) & 0b1111111);
    }

    public static int payload(long criteria) {
        return (int) (criteria);
    }

    public static boolean dominatesOrIsEqual(long criteria1, long criteria2) {
        Preconditions.checkArgument(hasDepMins(criteria1) == hasDepMins(criteria2));
        if (!hasDepMins(criteria1)) {
            return (arrMins(criteria1) <= arrMins(criteria2)) && (changes(criteria1) <= changes(criteria2));
        }
        return (depMins(criteria1) >= depMins(criteria2)) && (arrMins(criteria1) <= arrMins(criteria2)) && (changes(criteria1) <= changes(criteria2));
    }

    public static long withoutDepMins(long criteria) {
        return (criteria & 0b1000000000000111111111111111111111111111111111111111111111111111L);
    }

    public static long withDepMins(long criteria, int depMins1) {
        return (withoutDepMins(criteria) | ((~toUnsignedLong(depMins1+240)) & 0b111111111111 )<< 51);
    }

    public static long withAdditionalChange(long criteria) {
        return criteria + (0b100000000000000000000000000000000L);
    }

    public static long withPayload(long criteria, int payload1) {
        return ((criteria & 0b1111111111111111111111111111111100000000000000000000000000000000L) | payload1);
    }
}
