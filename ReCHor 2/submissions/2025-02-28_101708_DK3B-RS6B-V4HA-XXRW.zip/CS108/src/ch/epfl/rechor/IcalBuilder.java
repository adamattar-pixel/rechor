package ch.epfl.rechor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;

public final class IcalBuilder {
    private final ArrayList<Component> currentComponents = new ArrayList<>();
    private final StringBuilder wholeTextCalendar = new StringBuilder();
    public enum Component {
        VCALENDAR,
        VEVENT;
    }

    public enum Name {
        BEGIN,
        END,
        PRODID,
        VERSION,
        UID,
        DTSTAMP,
        DTSTART,
        DTEND,
        SUMMARY,
        DESCRIPTION;
    }


    public IcalBuilder add(Name name, String value) {
        //Preconditions.checkArgument(!currentComponents.isEmpty());
        StringBuilder valueText = new StringBuilder();
        valueText.append(name.toString()).append(":").append(value);
        int length = valueText.length();
        for (int i = 75; i < length; i += 76) {
            valueText.insert(i, "\r\n ");
            length++;
        }
        wholeTextCalendar.append(valueText).append("\r\n");
        return this;
    }

    public IcalBuilder add(Name name, LocalDateTime dateTime) {
        //Preconditions.checkArgument(!currentComponents.isEmpty());
        DateTimeFormatter fmt = new DateTimeFormatterBuilder()
                .appendValue(ChronoField.YEAR, 4)
                .appendValue(ChronoField.MONTH_OF_YEAR, 2)
                .appendValue(ChronoField.DAY_OF_MONTH, 2)
                .appendLiteral('T')
                .appendValue(ChronoField.HOUR_OF_DAY, 2)
                .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
                .appendValue(ChronoField.SECOND_OF_MINUTE, 2)
                .toFormatter();
        wholeTextCalendar.append(name.toString()).append(":").append(fmt.format(dateTime)).append("\r\n");
        return this;
    }

    public IcalBuilder begin(Component component) {
        wholeTextCalendar.append("BEGIN:").append(component.toString()).append("\r\n");
        currentComponents.add(component);
        return this;
    }

    public IcalBuilder end() {
        Preconditions.checkArgument(!currentComponents.isEmpty());
        wholeTextCalendar.append("END:").append(currentComponents.get(currentComponents.size() - 1).toString());
        wholeTextCalendar.append("\r\n");
        currentComponents.removeLast();
        return this;
    }

    public String build() {
        Preconditions.checkArgument(currentComponents.isEmpty());
        return wholeTextCalendar.toString();
    }
}
