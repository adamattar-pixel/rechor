package ch.epfl.rechor.journey;


import ch.epfl.rechor.FormatterFr;
import ch.epfl.rechor.IcalBuilder;

import java.time.LocalDateTime;
import java.util.StringJoiner;
import java.util.UUID;

import static ch.epfl.rechor.IcalBuilder.Component;
import static ch.epfl.rechor.IcalBuilder.Name;

public class JourneyIcalConverter {
    private JourneyIcalConverter() {}
    public static String toIcalendar(Journey journey) {
        IcalBuilder textBuilding = new IcalBuilder();
        textBuilding.begin(Component.VCALENDAR).
                add(Name.VERSION , "2.0").add(Name.PRODID , "ReCHor").
                begin(Component.VEVENT).
                add(Name.UID , UUID.randomUUID().toString()).add(Name.DTSTAMP , LocalDateTime.now()).add(Name.DTSTART ,journey.depTime()).
                add(Name.DTEND , journey.arrTime()).add(Name.SUMMARY , journey.depStop().name() + " → " + journey.arrStop().name());


        StringJoiner descriptionText = new StringJoiner("\\n");
        for (int i = 0; i < journey.legs().size(); i++) {
            switch (journey.legs().get(i)) {
                case Journey.Leg.Foot f ->
                    descriptionText.add(FormatterFr.formatLeg(f));
                case Journey.Leg.Transport t ->
                    descriptionText.add(FormatterFr.formatLeg(t));
            }
        }
        textBuilding.add(Name.DESCRIPTION, descriptionText.toString()).end().end();
        return textBuilding.build();
    }
}
