package ch.epfl.rechor.journey;


import ch.epfl.rechor.Preconditions;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static java.util.Objects.requireNonNull;

public record Journey(List<Leg> legs) {

    public sealed interface Leg {

        Stop depStop();
        LocalDateTime depTime();
        Stop arrStop();
        LocalDateTime arrTime();
        List<IntermediateStop> intermediateStops();
        default Duration duration(){
            return Duration.between(depTime(), arrTime());
        }

        record IntermediateStop(Stop stop, LocalDateTime arrTime, LocalDateTime depTime) {
            public IntermediateStop{
                requireNonNull(stop);
                requireNonNull(arrTime);
                requireNonNull(depTime);
                Preconditions.checkArgument(!depTime.isBefore(arrTime));
            }
        }

        record Transport(Stop depStop, LocalDateTime depTime, Stop arrStop, LocalDateTime arrTime, List<IntermediateStop> intermediateStops, Vehicle vehicle, String route, String destination) implements Leg {
            public Transport{
                requireNonNull(depStop);
                requireNonNull(depTime);
                requireNonNull(arrStop);
                requireNonNull(arrTime);
                requireNonNull(vehicle);
                requireNonNull(route);
                requireNonNull(destination);
                Preconditions.checkArgument(!arrTime.isBefore(depTime));
                intermediateStops = List.copyOf(intermediateStops);
            }
        }
        record Foot(Stop depStop, LocalDateTime depTime, Stop arrStop, LocalDateTime arrTime) implements Leg {
            public Foot{
                requireNonNull(depStop);
                requireNonNull(depTime);
                requireNonNull(arrStop);
                requireNonNull(arrTime);
                Preconditions.checkArgument(!arrTime.isBefore(depTime));
            }

            public List<IntermediateStop> intermediateStops(){ return Collections.emptyList(); }

            public boolean isTransfer(){
                return (depStop.name()).equals(arrStop.name());
            }
        }


    }

    public Journey {
        Preconditions.checkArgument(legs != null);
        Preconditions.checkArgument(!legs.isEmpty());
        for (int i = 1; i < legs.size(); i++) {
            Preconditions.checkArgument(!legs.get(i-1).getClass().equals(legs.get(i).getClass()));
            Preconditions.checkArgument(!legs.get(i).depTime().isBefore(legs.get(i-1).arrTime()));
        }
        legs = List.copyOf(legs);
    }

    public Stop depStop(){
        return legs.getFirst().depStop();
    }
    public Stop arrStop(){
        return legs.getLast().arrStop();
    }
    public LocalDateTime depTime(){
        return legs.getFirst().depTime();
    }
    public LocalDateTime arrTime(){
        return legs.getLast().arrTime();
    }

    public Duration duration() {
        return Duration.between(depTime(), arrTime());
    }

}
