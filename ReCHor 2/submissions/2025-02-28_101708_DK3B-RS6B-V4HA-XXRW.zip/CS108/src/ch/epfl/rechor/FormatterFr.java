package ch.epfl.rechor;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

import ch.epfl.rechor.journey.Stop;
import ch.epfl.rechor.journey.Journey;

public final class FormatterFr {

    public static String formatDuration(Duration duration) {
        if (duration.toMinutes() >= 60){
            return duration.toHours() + " h " + (duration.toMinutes() - duration.toHours()*60) + " min";
        } else {
            return duration.toMinutes() + " min";
        }
    }

    public static String formatTime(LocalDateTime dateTime) {
        DateTimeFormatter fmt = new DateTimeFormatterBuilder()
                .appendValue(ChronoField.HOUR_OF_DAY)
                .appendLiteral('h')
                .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
                .toFormatter();
        return fmt.format(dateTime);
    }

    public static String formatPlatformName(Stop stop) {
        if (stop.name() == null || stop.platformName() == null || stop.name().isEmpty() || stop.platformName().equals("")) {
            return "";
        }
        if (stop.platformName().charAt(0) >= '0' && stop.platformName().charAt(0) <= '9' ) {
            return "voie " + stop.platformName();
        }
        return "quai " + stop.platformName();
    }

    public static String formatLeg(Journey.Leg.Foot footLeg) {
        if (footLeg.isTransfer()) {
            return "changement (" + formatDuration(footLeg.duration()) + ")";
        } else {
            return "trajet à pied (" + formatDuration(footLeg.duration()) + ")";
        }
    }

    public static String formatLeg(Journey.Leg.Transport leg) {
        StringBuilder texte = new StringBuilder( formatTime(leg.depTime()) + " "  + leg.depStop().name());
        if (formatPlatformName((leg.depStop())).isEmpty()){
            texte.append(" → ");
        } else {
            texte.append(" (" + formatPlatformName(leg.depStop()) + ") → ");
        }
        if (formatPlatformName((leg.arrStop())).isEmpty()){
            texte.append(leg.arrStop().name() + " (arr. " + formatTime(leg.arrTime()) + ")");
        } else {
            texte.append(leg.arrStop().name() + " (arr. " + formatTime(leg.arrTime()) + " " + formatPlatformName(leg.arrStop()) + ")");
        }

        return texte.toString();

    }

    public static String formatRouteDestination(Journey.Leg.Transport transportLeg) {
        return transportLeg.route() + " Direction " + transportLeg.destination();
    }
}
