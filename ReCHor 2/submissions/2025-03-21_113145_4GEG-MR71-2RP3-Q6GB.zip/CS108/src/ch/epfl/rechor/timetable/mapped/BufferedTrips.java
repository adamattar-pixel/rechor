package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Trips;

import java.nio.ByteBuffer;
import java.util.List;

import static ch.epfl.rechor.timetable.mapped.Structure.field;

public final class BufferedTrips implements Trips {
    private static final int ROUTE_ID = 0;
    private static final int DESTINATION_ID = 1;
    private StructuredBuffer trips;
    private List<String> stringTable;

    public BufferedTrips(List<String> stringTable, ByteBuffer buffer) {
        this.stringTable = List.copyOf(stringTable);
        Structure structure = new Structure(field(ROUTE_ID, Structure.FieldType.U16), field(DESTINATION_ID, Structure.FieldType.U16));
        trips = new StructuredBuffer(structure, buffer);
    }

    @Override
    public int routeId(int id) {
        return trips.getU16(ROUTE_ID, id);
    }

    @Override
    public String destination(int id) {
        return stringTable.get(trips.getU16(DESTINATION_ID, id));
    }

    @Override
    public int size() {
        return trips.size();
    }
}
