package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.PackedRange;
import ch.epfl.rechor.timetable.Transfers;
import java.nio.ByteBuffer;
import java.util.NoSuchElementException;

import static ch.epfl.rechor.timetable.mapped.Structure.field;

public final class BufferedTransfers implements Transfers {
    private static final int DEP_STATION_ID = 0;
    private static final int ARR_STATION_ID = 1;
    private static final int TRANSFER_MINUTES = 2;
    private StructuredBuffer transfers;
    private int[] arrivals;

    public BufferedTransfers(ByteBuffer buffer) {
        Structure structure = new Structure(field(DEP_STATION_ID, Structure.FieldType.U16), field(ARR_STATION_ID, Structure.FieldType.U16), field(TRANSFER_MINUTES, Structure.FieldType.U8));
        transfers = new StructuredBuffer(structure, buffer);
        if (transfers.size() == 0) {
            arrivals = new int[0];
        } else {
            int diffArrival = transfers.getU16(ARR_STATION_ID, 0);
            for (int i = 1; i < size(); i++) {
                if (diffArrival < transfers.getU16(ARR_STATION_ID, i)) {
                    diffArrival = transfers.getU16(ARR_STATION_ID, i);
                }
            }
            arrivals = new int[diffArrival + 1];
        }


        for (int j = 0; j < arrivals.length; j++) {
            boolean diffStat = false ;
            int begStat = 0;
            int endStat = 0;
            for (int i = 0; i < size(); i++) {
                if (transfers.getU16(ARR_STATION_ID, i) == j && !diffStat) {
                    diffStat = true ;
                    begStat = i;
                    endStat = i;
                } else if (transfers.getU16(ARR_STATION_ID, i) != j) {
                    diffStat = false;
                }
                if (diffStat) {
                    endStat++;
                }
            }
            arrivals[j] = PackedRange.pack(begStat, endStat );
        }
    }

    @Override
    public int depStationId(int id) {
        return transfers.getU16(DEP_STATION_ID, id);
    }

    @Override
    public int minutes(int id) {
        return transfers.getU8(TRANSFER_MINUTES, id);
    }

    @Override
    public int arrivingAt(int stationId) {
        return arrivals[stationId];
    }

    @Override
    public int minutesBetween(int depStationId, int arrStationId) {
        for (int i = PackedRange.startInclusive(arrivingAt(arrStationId)); i < PackedRange.endExclusive(arrivingAt(arrStationId)); i++) {
            if (depStationId(i) == depStationId) {
                return minutes(i);
            }
        }
        throw new NoSuchElementException();
    }

    @Override
    public int size() {
        return transfers.size();
    }
}
