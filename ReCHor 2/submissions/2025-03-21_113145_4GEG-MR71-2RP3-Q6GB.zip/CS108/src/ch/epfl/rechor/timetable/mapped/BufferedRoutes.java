package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.journey.Vehicle;
import ch.epfl.rechor.timetable.Routes;


import java.util.List;
import java.nio.ByteBuffer;

import static ch.epfl.rechor.timetable.mapped.Structure.field;

public final class BufferedRoutes implements Routes {
    private static final int NAME_ID = 0;
    private static final int KIND = 1;
    private StructuredBuffer routes;
    private List<String> stringTable;

    public BufferedRoutes(List<String> stringTable, ByteBuffer buffer){
        this.stringTable = List.copyOf(stringTable);
        Structure structure = new Structure(field(NAME_ID, Structure.FieldType.U16), field(KIND, Structure.FieldType.U8));
        routes = new StructuredBuffer(structure, buffer);
    }
    @Override
    public Vehicle vehicle(int id) {
        return Vehicle.ALL.get(routes.getU8(KIND, id));
    }

    @Override
    public String name(int id) {
        return stringTable.get(routes.getU16(NAME_ID, id));
    }

    @Override
    public int size() {
        return routes.size();
    }
}
