package ch.epfl.rechor.journey;

import ch.epfl.rechor.FormatterFr;
import ch.epfl.rechor.Preconditions;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.LongConsumer;

import static ch.epfl.rechor.journey.PackedCriteria.*;
import static java.lang.System.arraycopy;

public class ParetoFront {

    public static class Builder {
        private long[] currentPareto;
        private int effectiveCapacity;
        public final static int initialCapacity = 2;

        public Builder() {
            currentPareto = new long[initialCapacity];
            effectiveCapacity = 0;
        }

        public Builder(Builder that) {
            effectiveCapacity = that.effectiveCapacity;
            currentPareto = that.currentPareto.clone();
        }

        public int effectiveCapacity() {
            return effectiveCapacity;
        }

        public long[] currentPareto() {
            return currentPareto.clone();
        }

        public boolean isEmpty() {
            return effectiveCapacity == 0;
        }

        public Builder clear() {
            currentPareto = new long[initialCapacity];
            effectiveCapacity = 0;
            return this;
        }

        public void forEach(LongConsumer action) {
            for (int i = 0; i < effectiveCapacity; i++) {
                action.accept(currentPareto[i]);
            }
        }

        public Builder add(long packedTuple) {
            //Trouver le premier element
            long tempPackedTuple = withPayload(packedTuple, Integer.MAX_VALUE);
            int insertIndex = 0;
            int currentIndex = 0;
            while (insertIndex == 0 && currentIndex < effectiveCapacity) {
                if (dominatesOrIsEqual(currentPareto[currentIndex], packedTuple)) {
                    return this;
                }
                if (tempPackedTuple < currentPareto[currentIndex]) {
                    insertIndex = currentIndex;
                    break;
                }
                currentIndex++;
                if (currentIndex == effectiveCapacity) {
                    insertIndex = effectiveCapacity;
                }
            }
            //Laisser les non-domines
            int dst = insertIndex;
            for (int idx = insertIndex; idx < effectiveCapacity; ++idx) {
                if (dominatesOrIsEqual(packedTuple, currentPareto[idx])) continue;
                if (dst != idx) {
                    currentPareto[dst] = currentPareto[idx];
                }
                dst += 1;
            }
            effectiveCapacity = dst;
            //inserer lelement
            if (effectiveCapacity >= currentPareto.length) {
                long[] tempPareto = new long[(int) (currentPareto.length * 1.5)];
                arraycopy(currentPareto, 0, tempPareto, 0, insertIndex);
                arraycopy(currentPareto, insertIndex, tempPareto, insertIndex + 1, effectiveCapacity - (insertIndex));
                tempPareto[insertIndex] = packedTuple;
                currentPareto = tempPareto;
            } else {
                arraycopy(currentPareto, insertIndex, currentPareto, insertIndex + 1, effectiveCapacity - (insertIndex));
                currentPareto[insertIndex] = packedTuple;
            }
            effectiveCapacity++;
            return this;
        }

        public Builder add(int arrMins, int changes, int payload) {
            add(pack(arrMins, changes, payload));
            return this;
        }

        public Builder addAll(Builder that) {
            for (int i = 0; i < that.effectiveCapacity; i++) {
                add(that.currentPareto[i]);
            }
            return this;
        }

        public boolean fullyDominates(Builder that, int depMins) {
            long[] tempPareto = new long[that.effectiveCapacity];
            for (int i = 0; i < that.effectiveCapacity; i++) {
                tempPareto[i] = withDepMins(that.currentPareto[i], depMins);
            }

            boolean dominates = true;
            for (int i = 0; i < tempPareto.length; i++) {
                dominates = false;
                for (int j = 0; j < effectiveCapacity; j++) {
                    if (dominatesOrIsEqual(currentPareto[j], tempPareto[i])) {
                        dominates = true;
                    }
                }
                if (!dominates) {
                    return false;
                }
            }
            return dominates;
        }

        public ParetoFront build() {
            long[] tempPareto = new long[effectiveCapacity];
            arraycopy(currentPareto, 0, tempPareto, 0, effectiveCapacity);
            return new ParetoFront(tempPareto);
        }

        @Override
        public String toString() {
            StringBuilder s = new StringBuilder();
            forEach(value -> {
                if (!hasDepMins(value)) {
                    s.append(arrMins(value)).append(" ").append(changes(value)).append(" ").append(payload(value)).append("\r\n");
                } else {
                    s.append(depMins(value)).append(" ").append(arrMins(value)).append(" ").append(changes(value)).append(" ").append(payload(value)).append("\r\n");
            } });
            return s.toString();
        }
    }

    private final long[] tuple;
    public static final ParetoFront EMPTY = new ParetoFront(new long[0]);

    private ParetoFront(long[] tuple) {
        this.tuple = tuple;
    }

    public int size() {
        return tuple.length;
    }

    public long get(int arrMins, int changes) {
        for (int i = 0; i < size(); i++) {
            if (arrMins(tuple[i]) == arrMins) {
                if (changes(tuple[i]) == changes) {
                    return tuple[i];
                }
            }
        }
        throw new NoSuchElementException();
    }

    public void forEach(LongConsumer action) {
        for (int i = 0; i < size(); i++) {
            action.accept(tuple[i]);
        }
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        forEach(value -> {
            if (!hasDepMins(value)) {
                s.append(arrMins(value)).append(" ").append(changes(value)).append(" ").append(payload(value)).append("\r\n");
            } else {
                s.append(depMins(value)).append(" ").append(arrMins(value)).append(" ").append(changes(value)).append(" ").append(payload(value)).append("\r\n");
            } });
        return s.toString();
    }
}
