package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.Bits32_24_8;
import ch.epfl.rechor.timetable.Connections;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import static ch.epfl.rechor.timetable.mapped.Structure.field;

public final class BufferedConnections implements Connections {
    private static final int DEP_STOP_ID = 0;
    private static final int DEP_MINUTES = 1;
    private static final int ARR_STOP_ID = 2;
    private static final int ARR_MINUTES = 3;
    private static final int TRIP_POS_ID = 4;
    private StructuredBuffer flattenedConnections;
    private IntBuffer nextConnection;

    private StructuredBuffer platforms;
    public BufferedConnections(ByteBuffer buffer, ByteBuffer succBuffer) {
        Structure structure1 = new Structure(field(DEP_STOP_ID, Structure.FieldType.U16), field(DEP_MINUTES, Structure.FieldType.U16), field(ARR_STOP_ID, Structure.FieldType.U16), field(ARR_MINUTES, Structure.FieldType.U16) , field(TRIP_POS_ID, Structure.FieldType.S32));
        flattenedConnections = new StructuredBuffer(structure1, buffer);
        nextConnection = succBuffer.asIntBuffer();
    }

    @Override
    public int depStopId(int id) {
        return flattenedConnections.getU16(DEP_STOP_ID, id);
    }

    @Override
    public int depMins(int id) {
        return flattenedConnections.getU16(DEP_MINUTES, id);
    }

    @Override
    public int arrStopId(int id) {
        return flattenedConnections.getU16(ARR_STOP_ID, id);
    }

    @Override
    public int arrMins(int id) {
        return flattenedConnections.getU16(ARR_MINUTES, id);
    }

    @Override
    public int tripId(int id) {
        return Bits32_24_8.unpack24(flattenedConnections.getS32(TRIP_POS_ID, id));
    }

    @Override
    public int tripPos(int id) {
        return Bits32_24_8.unpack8(flattenedConnections.getS32(TRIP_POS_ID, id));
    }

    @Override
    public int nextConnectionId(int id) {
        return nextConnection.get(id);
    }

    @Override
    public int size() {
        return flattenedConnections.size();
    }
}
