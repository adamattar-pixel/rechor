package ch.epfl.rechor.timetable.mapped;


import ch.epfl.rechor.Preconditions;


public class Structure {
    private Field[] fields;
    private int[] indexTable;

    public Structure(Field... fields) {
        this.fields = new Field[fields.length];
        this.indexTable = new int[fields.length];
        int currentSize = 0;

        for ( int i = 0 ; i < fields.length ; i++){
            Preconditions.checkArgument(fields[i].index() == i);
            this.indexTable[i] = currentSize;
            switch (fields[i].type()) {
                case U8 :
                    currentSize += 1;
                    break;
                case U16 :
                    currentSize += 2;
                    break;
                case S32 :
                    currentSize += 4;
                    break;
            }
            this.fields[i] = fields[i];
        }
    }


    public int totalSize(){
        int numByte = 0;
        for (int i = 0 ; i < fields.length ; i++){
            switch (fields[i].type()) {
                case U8 :
                    numByte += 1;
                    break;
                case U16 :
                    numByte += 2;
                    break;
                case S32 :
                    numByte += 4;
                    break;
            }
        }
        return numByte;
    }

    public int offset(int fieldIndex, int elementIndex){
        if (elementIndex < 0 || fieldIndex < 0){
            throw new IndexOutOfBoundsException();
        }
        return elementIndex * totalSize() + indexTable[fieldIndex];
    }

    public enum FieldType {
        U8 ,
        U16,
        S32;
    }

    public record Field(int index, FieldType type){
        public Field {
            if (type == null) {
                throw new NullPointerException();
            }
        }

    }

    public static Field field(int index, FieldType type) {
        return new Field(index, type);
    }
}
