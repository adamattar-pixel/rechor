package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Stations;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.List;
import static ch.epfl.rechor.timetable.mapped.Structure.field;
import static java.lang.Math.scalb;

public final class BufferedStations implements Stations {
    private static final int NAME_ID = 0;
    private static final int LON = 1;
    private static final int LAT = 2;
    private StructuredBuffer stations;
    private List<String> stringTable;

    public BufferedStations(List<String> stringTable, ByteBuffer buffer) {
        this.stringTable = List.copyOf(stringTable);
        Structure structure = new Structure(field(NAME_ID, Structure.FieldType.U16), field(LON, Structure.FieldType.S32), field(LAT, Structure.FieldType.S32));
        stations = new StructuredBuffer(structure, buffer);
    }

    @Override
    public String name(int id) {
        return stringTable.get(stations.getU16(NAME_ID, id));
    }

    @Override
    public double longitude(int id) {
        return scalb((stations.getS32(LON, id) * 360.0), -32);
    }

    @Override
    public double latitude(int id) {
        return scalb((stations.getS32(LAT, id) * 360.0), -32);
    }

    @Override
    public int size() {
        return stations.size();
    }
}
