package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Platforms;

import java.nio.ByteBuffer;
import java.util.List;
import static ch.epfl.rechor.timetable.mapped.Structure.field;

public final class BufferedPlatforms implements Platforms {
    private static final int NAME_ID = 0;
    private static final int STATION_ID = 1;
    private StructuredBuffer platforms;
    private List<String> stringTable;

    public BufferedPlatforms(List<String> stringTable, ByteBuffer buffer){
        this.stringTable = List.copyOf(stringTable);
        Structure structure = new Structure(field(NAME_ID, Structure.FieldType.U16), field(STATION_ID, Structure.FieldType.U16));
        platforms = new StructuredBuffer(structure, buffer);
    }


    @Override
    public int stationId(int id) {
        return platforms.getU16(STATION_ID, id);
    }

    @Override
    public String name(int id) {
        return stringTable.get(platforms.getU16(NAME_ID, id));
    }

    @Override
    public int size() {
        return platforms.size();
    }
}
