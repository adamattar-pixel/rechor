package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.StationAliases;

import java.nio.ByteBuffer;
import java.util.List;
import static ch.epfl.rechor.timetable.mapped.Structure.field;


public final class BufferedStationAliases implements StationAliases {
    private static final int ALIAS_ID = 0;
    private static final int STATION_NAME_ID = 1;
    private StructuredBuffer stationsAliases;
    private List<String> stringTable;

    public BufferedStationAliases(List<String> stringTable, ByteBuffer buffer){
        this.stringTable = List.copyOf(stringTable);
        Structure structure = new Structure(field(ALIAS_ID, Structure.FieldType.U16), field(STATION_NAME_ID, Structure.FieldType.U16));
        stationsAliases = new StructuredBuffer(structure, buffer);
    }


    @Override
    public String alias(int id) {
        return stringTable.get(stationsAliases.getU16(ALIAS_ID, id));
    }

    @Override
    public String stationName(int id) {
        return stringTable.get(stationsAliases.getU16(STATION_NAME_ID, id));
    }

    @Override
    public int size() {
        return stationsAliases.size();
    }
}
