package ch.epfl.rechor.timetable;

import java.time.LocalDate;

public interface TimeTable {
    Stations stations();
    StationAliases stationAliases();
    Platforms platforms();
    Routes routes();
    Transfers transfers();
    Trips tripsFor(LocalDate date);
    Connections connectionsFor(LocalDate date);

    default boolean isStationId(int stopId) {
        return stopId < stations().size() && stopId >= 0;
    }
    default boolean isPlatformId(int stopId) {
        return !isStationId(stopId) && stopId < (platforms().size() + stations().size()) && stopId >= 0;
    }
    default int stationId(int stopId) {
        if (isStationId(stopId)) {
            return stopId;
        }
        return platforms().stationId(stopId - stations().size());
    }
    default String platformName(int stopId) {
        if (isStationId(stopId)) {
            return null;
        }
        return platforms().name(stopId - stations().size());
    }
}
