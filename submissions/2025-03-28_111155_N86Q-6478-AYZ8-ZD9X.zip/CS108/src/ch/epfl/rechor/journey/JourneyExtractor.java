package ch.epfl.rechor.journey;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

import ch.epfl.rechor.timetable.*;

import static ch.epfl.rechor.Bits32_24_8.unpack24;
import static ch.epfl.rechor.Bits32_24_8.unpack8;
import static ch.epfl.rechor.journey.Journey.Leg;
import static ch.epfl.rechor.journey.Journey.Leg.Transport;
import static ch.epfl.rechor.journey.Journey.Leg.Foot;
import static ch.epfl.rechor.journey.Journey.Leg.IntermediateStop;
import static ch.epfl.rechor.journey.PackedCriteria.*;

/**
 * Classe utilitaire pour extraire des trajets (Journeys) basés sur un profil donné.
 * Cette classe ne peut pas être instanciée directement car elle est conçue pour
 * fournir des méthodes statiques d'extraction de trajets.
 */
public class JourneyExtractor {
    /**
     * Constructeur privé pour empêcher l'instanciation directe de cette classe.
     */
    private JourneyExtractor() {}


    /**
     * Extrait et retourne une liste de trajets possibles à partir d'un profil donné
     * et d'une station de départ. Les trajets sont triés par heure de départ, puis
     * par heure d'arrivée.
     *
     * @param profile       le profil de recherche contenant les informations nécessaires
     *                      pour extraire les trajets, y compris l'horaire, la date,
     *                      et les fronts de Pareto pour les stations.
     * @param depStationId  l'identifiant de la station de départ à partir de laquelle
     *                      les trajets doivent être calculés.
     * @return une liste de trajets possibles triés par heure de départ puis par
     *         heure d'arrivée.
     */
    public static List<Journey> journeys(Profile profile, int depStationId) {
        ParetoFront pf = profile.forStation(depStationId);
        List<Journey> journeys = new ArrayList<>();

        pf.forEach((long criteria) -> {
            long currentCriteria = criteria;
            int connectionId = unpack24(payload(currentCriteria));
            int intermediateStopsNum = unpack8(payload(currentCriteria));
            Stations stations = profile.timeTable().stations();
            Connections connections = profile.connections();
            Transfers transfers = profile.timeTable().transfers();
            LocalDateTime temp = profile.date().atTime(0, 0).plusMinutes(depMins(currentCriteria));;
            int changes = changes(currentCriteria);
            int depStationLegId = 0;
            int arrStationLegId = depStationId;

            boolean isFootLeg = false;
            if (profile.timeTable().stationId(connections.depStopId(connectionId)) != depStationId) {
                isFootLeg = true;
            }

            List<Leg> legs = new ArrayList<>();
            while (changes >= 0) {
                Leg leg;

                if (!isFootLeg) {
                    changes--;
                    List<IntermediateStop> intermediateStops = new ArrayList<>();
                    int arrStopId = connectionId;
                    for (int i = 0; i < intermediateStopsNum; i++) {
                        LocalDateTime arrTime = profile.date().atTime(0, 0).plusMinutes(connections.arrMins(arrStopId));
                        arrStopId = connections.nextConnectionId(arrStopId);
                        depStationLegId = profile.timeTable().stationId(connections.depStopId(arrStopId));
                        Stop depStop = new Stop(stations.name(depStationLegId), profile.timeTable().platformName(connections.depStopId(arrStopId)), stations.longitude(depStationLegId), stations.latitude(depStationLegId));
                        LocalDateTime depTime = profile.date().atTime(0, 0).plusMinutes(connections.depMins(arrStopId));
                        intermediateStops.add(new IntermediateStop(depStop, arrTime, depTime));
                    }

                    depStationLegId = profile.timeTable().stationId(connections.depStopId(connectionId));
                    arrStationLegId = profile.timeTable().stationId(connections.arrStopId(arrStopId));

                    Stop depStop = new Stop(stations.name(depStationLegId), profile.timeTable().platformName(connections.depStopId(connectionId)), stations.longitude(depStationLegId), stations.latitude(depStationLegId));
                    LocalDateTime depTime = profile.date().atTime(0, 0).plusMinutes(connections.depMins(connectionId));
                    Stop arrStop = new Stop(stations.name(arrStationLegId), profile.timeTable().platformName(connections.arrStopId(arrStopId)), stations.longitude(arrStationLegId), stations.latitude(arrStationLegId));
                    LocalDateTime arrTime = profile.date().atTime(0, 0).plusMinutes(connections.arrMins(arrStopId));
                    temp = arrTime;
                    Routes routes = profile.timeTable().routes();
                    Trips trips = profile.timeTable().tripsFor(profile.date());
                    Vehicle vehicle = routes.vehicle(trips.routeId(connections.tripId(arrStopId)));
                    String route = routes.name(trips.routeId(connections.tripId(arrStopId)));
                    String destination = trips.destination(connections.tripId(arrStopId));
                    leg = new Transport(depStop, depTime, arrStop, arrTime, intermediateStops, vehicle, route, destination);
                    isFootLeg = true;
                    if (changes >= 0) {
                        currentCriteria = profile.forStation(arrStationLegId).get(arrMins(currentCriteria), changes);
                        connectionId = unpack24(payload(currentCriteria));
                        intermediateStopsNum = unpack8(payload(currentCriteria));
                    }
                } else {
                    depStationLegId = arrStationLegId;
                    arrStationLegId = profile.timeTable().stationId(connections.depStopId(connectionId));

                    Stop depStop = new Stop(stations.name(depStationLegId), profile.timeTable().platformName(connections.depStopId(connectionId)), stations.longitude(depStationLegId), stations.latitude(depStationLegId));
                    LocalDateTime depTime = temp;
                    Stop arrStop = new Stop(stations.name(arrStationLegId), profile.timeTable().platformName(connections.arrStopId(connectionId)), stations.longitude(arrStationLegId), stations.latitude(arrStationLegId));
                    LocalDateTime arrTime = depTime.plusMinutes(transfers.minutesBetween(depStationLegId, arrStationLegId));
                    leg = new Foot(depStop, depTime, arrStop, arrTime);
                    isFootLeg = false;

                }
                legs.add(leg);
                if (changes == -1 && profile.arrStationId() != arrStationLegId) {
                    depStationLegId = arrStationLegId;
                    arrStationLegId = profile.arrStationId();

                    Stop depStop = new Stop(stations.name(depStationLegId), profile.timeTable().platformName(connections.depStopId(connectionId)), stations.longitude(depStationLegId), stations.latitude(depStationLegId));
                    LocalDateTime depTime = temp;
                    Stop arrStop = new Stop(stations.name(arrStationLegId), profile.timeTable().platformName(connections.arrStopId(connectionId)), stations.longitude(arrStationLegId), stations.latitude(arrStationLegId));
                    LocalDateTime arrTime = depTime.plusMinutes(transfers.minutesBetween(depStationLegId, arrStationLegId));
                    legs.add(new Foot(depStop, depTime, arrStop, arrTime));
                }
            }
            journeys.add(new Journey(legs));
        });

        /** Tri des trajets par heure de départ, puis par heure d'arrivée */
        journeys.sort(Comparator
                .comparing(Journey::depTime)
                .thenComparing(Journey::arrTime));

        return journeys;
    }
}
